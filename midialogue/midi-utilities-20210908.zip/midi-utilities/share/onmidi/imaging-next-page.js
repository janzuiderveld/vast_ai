var Shell = WScript.CreateObject("WScript.Shell");
Shell.AppActivate("Imaging");
Shell.SendKeys("%pn");
