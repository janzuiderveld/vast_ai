
Experiments in isomorphic keyboard layouts.  The first number refers to the
interval (number of half-steps) when moving one key to the right in the same
row.  The second number refers to the interval when moving one row upwards (and
slightly to the right, since they're staggered).

Certain of the layouts should be familiar from elsewhere:

1-5 is the bass guitar
1-7 is the violin and mandolin
2-1 is the Janko piano
2-7 is the Hayden/Wicki concertina

