
package com.sreal.midifile;

public interface EventVisitor
{
	public void visitEvent(com.sreal.midifile.Event event);
}

