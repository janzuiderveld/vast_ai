#ifndef KEYNAMES_INCLUDED
#define KEYNAMES_INCLUDED

char *GetKeyNameByScanCode(int scan_code);
int GetScanCodeByKeyName(char *key_name);

#endif
