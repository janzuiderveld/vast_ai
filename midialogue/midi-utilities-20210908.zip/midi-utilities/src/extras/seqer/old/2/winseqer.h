#ifndef WINSEQER_INCLUDED
#define WINSEQER_INCLUDED

#ifdef __cplusplus
extern "C"
{
#endif

#define STATUS_BAR_ID 0

#ifdef __cplusplus
}
#endif

#endif
