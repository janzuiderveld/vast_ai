var Shell = WScript.CreateObject("WScript.Shell");
Shell.SendKeys("%s");
